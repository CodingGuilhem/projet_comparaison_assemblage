#include "boxedtext.h"
#include <libgen.h>
#include <cstring>
#include <iostream>

using namespace std;
using namespace DoccY;

void usage(char *progname, const char *msg = NULL) {
  if (msg) {
    cerr << msg << endl;
  }
  cerr << "Usage: " << basename(progname) << " [-i|--interactive] [alignment] <file>" << endl
       << "Where 'alignment' is either:" << endl
       << "  -l|--left" << endl
       << "  -r|--right" << endl
       << "  -j|--justifiy" << endl
       << "  -c|--center" << endl
       << "  -a|--asis" << endl;
}

int main(int argc, char** argv) {

  BoxedText::Alignment align = BoxedText::ALIGN_LEFT;
;
  bool inter = false;
  char *fich = NULL;

  if ((argc < 2) || (argc > 4)) {
    usage(argv[0]);
    return 1;
  }

  if (argc == 2) {
    align = BoxedText::ALIGN_LEFT;
    fich = argv[1];
  } else {
    char *opt = NULL;
    if (argc == 3) {
      if (strcmp(argv[1], "-i") && strcmp(argv[1], "--interactive")) {
	opt = argv[1];
      } else {
	align = BoxedText::ALIGN_LEFT;
	inter = true;
      }
      fich = argv[2];
    } else {
      if (strcmp(argv[1], "-i") && strcmp(argv[1], "--interactive")) {
	usage(argv[0]);
	return 1;
      }
      inter = true;
      opt = argv[2];
      fich = argv[3];
    }
    if (opt) {
      if (opt[0] != '-') {
	usage(argv[0], "Bad usage!!!");
	return 1;
      }
      if (opt[1] == '-') {
	if (!strcmp(opt+2, "left")) {
	  align = BoxedText::ALIGN_LEFT;
	} else {
	  if (!strcmp(opt+2, "right")) {
	    align = BoxedText::ALIGN_RIGHT;
	  } else {
	    if (!strcmp(opt+2, "center")) {
	      align = BoxedText::ALIGN_CENTER;
	    } else {
	      if (!strcmp(opt+2, "justifiy")) {
		align = BoxedText::ALIGN_JUSTIFY;
	      } else {
		if (!strcmp(opt+2, "asis")) {
		  align = BoxedText::PRINT_ASIS;
		} else {
		  usage(argv[0], "Unknown option!!!");
		  return 1;
		}
	      }
	    }
	  }
	}
      } else {
	if (opt[1] == '\0') {
	  usage(argv[0], "Bad usage!!!");
	  return 1;
	} else {
	  if (opt[2] != '\0') {
	    usage(argv[0], "Unknown option!!!");
	    return 1;
	  } else {
	    switch (opt[1]) {
	    case 'l':
	      align = BoxedText::ALIGN_LEFT;
	      break;
	    case 'r':
	      align = BoxedText::ALIGN_RIGHT;
	      break;
	    case 'c':
	      align = BoxedText::ALIGN_CENTER;
	      break;
	    case 'j':
	      align = BoxedText::ALIGN_JUSTIFY;
	      break;
	    case 'a':
	      align = BoxedText::PRINT_ASIS;
	      break;
	    default:
	      usage(argv[0], "Unknown option!!!");
	      return 1;
	      break;
	    }
	  }
	}
      }
    }
  }

  BoxedText test;

  test.readFile(fich);
  test.interactive(inter);
  test.setBorder("\u2554", BoxedText::TOP_LEFT_CORNER);
  test.setBorder("\u2557", BoxedText::TOP_RIGHT_CORNER);
  test.setBorder("\u255F", BoxedText::MIDDLE_LEFT_CORNER);
  test.setBorder("\u2562", BoxedText::MIDDLE_RIGHT_CORNER);
  test.setBorder("\u255A", BoxedText::BOTTOM_LEFT_CORNER);
  test.setBorder("\u255D", BoxedText::BOTTOM_RIGHT_CORNER);
  test.setBorder("\u2550", BoxedText::HORIZONTAL_LINES);
  test.setBorder("\u2500", BoxedText::MIDDLE_LINE);
  test.setBorder("\u2551", BoxedText::VERTICAL_LINES);
  test.rightMargin(2);
  test.leftMargin(2);
  test.alignment(align);
  test.doWarn(true);
  test.noEscape(false);
  cout << test << endl;
  return 0;
}
