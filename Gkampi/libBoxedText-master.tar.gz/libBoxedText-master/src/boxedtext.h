#ifndef __BOXEDTEXT_H__
#define __BOXEDTEXT_H__

/**
 * \mainpage
 * \brief     Pretty print enriched text on a console terminal
 * \author    Alban Mancheron <alban.mancheron@lirmm.fr>
 * \copyright © 2015-2023 -- LIRMM/UM/CNRS
 *                           (Laboratoire d'Informatique, de Robotique et de
 *                           Microélectronique de Montpellier /
 *                           Université de Montpellier /
 *                           Centre National de la Recherche Scientifique)
 *
 *
 * The printed content can be enriched by specific (HTML-like) tags in order to improve its display.
 * Currently, the supported tags are:
 * | Tag       | Description                                                        |
 * | --------- | ------------------------------------------------------------------ |
 * | `hr`      | Display a horizontal line                                          |
 * | `p`       | Delimit an parapgraph                                              |
 * | `br`      | Force a line break                                                 |
 * | `center`  | Center the enclosed text                                           |
 * | `left`    | Left align the enclosed text                                       |
 * | `right`   | Right align the enclosed text                                      |
 * | `justify` | Justify the enclosed text                                          |
 * | `pre`     | Print the text asis (do not interpret the tags but &lt;/pre&gt;    |
 * | `color`   | Modify the color of the enclosed text (see below)                  |
 * | `b`       | Display the enclosed text in bold font                             |
 * | `i`       | Display the enclosed text in italic                                |
 * | `u`       | Underline the enclosed text                                        |
 * | `blink`   | Make the enclosed text blinking (if supported by the terminal)     |
 * | `reverse` | Do a reverse video                                                 |
 *
 * The color tag needs at least one of the following (key=value) parameters:
 * - `fg` Set the foreground color
 * - `bg` Set the background color
 * .
 * The following colors are accepted:
 * - `black`
 * - `red`
 * - `green`
 * - `yellow`
 * - `blue`
 * - `magenta`
 * - `cyan`
 * - `white`
 * .
 */

/*
 * \file      boxedtext.h
 * \brief     Pretty print enriched text on a console terminal
 * \author    Alban Mancheron <alban.mancheron@lirmm.fr>
 * \copyright © 2015-2023 -- LIRMM/UM/CNRS
 *                           (Laboratoire d'Informatique, de Robotique et de
 *                           Microélectronique de Montpellier /
 *                           Université de Montpellier /
 *                           Centre National de la Recherche Scientifique)
 */

#include <sstream>
#include <vector>
#include <string>

/**
 * \namespace DoccY
 * \brief The namespace for the DoccY's C++ contributions.
 * \author    Alban Mancheron <alban.mancheron@lirmm.fr>
 * \copyright © 2015-2023 -- LIRMM/UM/CNRS
 *                           (Laboratoire d'Informatique, de Robotique et de
 *                           Microélectronique de Montpellier /
 *                           Université de Montpellier /
 *                           Centre National de la Recherche Scientifique)
 *
 * For my personal convenience, I have decided to put all my C++ contributions
 * in this namespace.
 */
namespace DoccY {

  extern "C" {
    /**
     * \fn char *libBoxedTextVersion();
     * \brief One can use this "C" function to test the library availability
     * \return This function returns a C string representing the current BoxedText
     * library version number.
     */
    char *libBoxedTextVersion();
  }

  /**
   * \class BoxedText.
   * \brief A C++ class to format enriched text in order to be printed on a console terminal.
   * \author    Alban Mancheron <alban.mancheron@lirmm.fr>
   * \copyright © 2015-2023 -- LIRMM/UM/CNRS
   *                           (Laboratoire d'Informatique, de Robotique et de
   *                           Microélectronique de Montpellier /
   *                           Université de Montpellier /
   *                           Centre National de la Recherche Scientifique)
   *
   * This class inherits from std::stringstream. The content of an object is parsed only when printed
   * on a stream.
   */
  class BoxedText: public std::stringstream {

  public:
    /**
     * \enum Alignment
     * \brief Specify the global or local alignment inside the box/paragraph.
     */
    enum Alignment {
      ALIGN_LEFT,    /**< Left align the text. */
      ALIGN_CENTER,  /**< Center the text. */
      ALIGN_RIGHT,   /**< Right align the text. */
      ALIGN_JUSTIFY, /**< Justify the text. */
      PRINT_ASIS      /**< Print the text as it is typeset (wraps the long lines if necessary). */
    };

  private:
    /**
     * \fn std::ostream &operator<<(std::ostream &os, const BoxedText &bt);
     */
    friend std::ostream &operator<<(std::ostream &os, const BoxedText &bt);

    const char *_topleftcorner,     /**< The string to display for the top left corner. */
               *_toprightcorner,    /**< The string to display for the top right corner. */
               *_middleleftcorner,  /**< The string to display for the middle left corner. */
               *_middlerightcorner, /**< The string to display for the middle right corner. */
               *_bottomleftcorner,  /**< The string to display for the bottom left corner. */
               *_bottomrightcorner, /**< The string to display for the bottom left corner. */
               *_upperline,         /**< The string pattern to display for the upper horizontal line. */
               *_lowerline,         /**< The string pattern to display for the lower horizontal line. */
               *_middleline,        /**< The string pattern to display for the middle horizontal line. */
               *_leftline,          /**< The string pattern to display for the left vertical line. */
               *_rightline;         /**< The string pattern to display for the right vertical line. */

    unsigned int _totalwidth,  /**< Total width (including frame) to use for displaying the content
				    of the current object. */
                 _totalheight, /**< Total height (including frame) to use for displaying the content
				    of the current object (if interactive is set). */
                 _leftmargin,  /**< The extra space between the left border of the frame and the text. */
                 _rightmargin; /**< The extra space between the right border of the frame and the text. */
    Alignment _alignment;      /**< The global (default) alignment of the text inside the frame. */
    bool _nowarn,              /**< if nowarn is true, no warning are output on error stream when a
				    formatting problem occurs. */
	 _interacts,           /**< if interacts is true, then display is segmented according to
				    totalheight and user needs to press a key to continue. */
	 _no_escape;           /**< if _no_escape is true, then escape codes are removed from display. */

    static std::vector<std::string> _keywords, /**< Accepted formatting tags. */
				   _colors;    /**< Accepted color names. */

    /**
     * \brief Load the accepted keywords.
     *
     * User don't have to call this method. It is automatically done if necessary.
     */
    static void initKeywords();

    /**
     * \brief Load the accepted color names.
     *
     * User don't have to call this method. It is automatically done if necessary.
     */
    static void initColors();


    /**
     * \brief Check if the char string pointed by tag is a valid keyword.
     *
     * User don't have to call this method. It is automatically done if necessary.
     */
    static bool isValidTag(const char *tag, const Alignment align);

    /**
     * \brief Initialize the current object attributes.
     *
     * This method is used by the constructors to set all its attributes.
     *
     * \param topleftcorner      Top left corner string.
     * \param toprightcorner     Top right corner string.
     * \param middleleftcorner   Middle left corner string.
     * \param middlerightcorner  Middle right corner string.
     * \param bottomleftcorner   Bottom left corner string.
     * \param bottomrightcorner  Bottom right corner string.
     * \param upperline          Upper horizontal line string.
     * \param lowerline          Lower horizontal line string.
     * \param middleline         Middle horizontal line string.
     * \param leftline           Left vertical line string.
     * \param rightline          Right vertical line string.
     * \param totalwidth         Total width of the framed box.
     * \param totalheight        Total height of the framed box.
     * \param leftmargin         Left margin between the box border and the text.
     * \param rightmargin        Right margin between the text and the box border.
     * \param alignment          Default (global) text alignment inside the box.
     * \param nowarn             Set to true to disable warnings.
     * \param interacts          Set to true to display interactively the content.
     * \param no_escape          Set to true to discard escape ansi codes.
     */
    void init(const char *topleftcorner, const char *toprightcorner,
	      const char *middleleftcorner, const char *middlerightcorner,
	      const char *bottomleftcorner, const char *bottomrightcorner,
	      const char *upperline, const char *lowerline, const char *middleline,
	      const char *leftline, const char *rightline,
	      const unsigned int totalwidth, const unsigned int totalheight,
	      const unsigned int leftmargin, const unsigned int rightmargin,
	      const Alignment alignment, bool nowarn, bool interacts, bool no_escape);

  public:

    /**
     * \brief Standard constructor
     *
     * By default, the frame is entirely drawn with the character '*', margins are 1 character
     * large and has the maximum available width (terminal width). The text is left-aligned,
     * no warning is displayed and it runs in non interactive mode.
     *
     * It is possible to change the default behaviour by setting the different components. If
     * you wan't a more customized BoxedText, then use the detailed constructor.
     *
     * \param corners Set all corners to the given string (default: "*").
     * \param lines   Set all lines' patterns to the given string (default : "*").
     * \param w       Set the total width to use (0 means autodetect and use terminal width).
     * \param margins Set the left and right margins (default: 1).
     * \param align   Set the global alignment inside the frame (default: left align).
     * \param nowarn  When true, deactivate warnings (default: true).
     */
    BoxedText(const char *corners = "*", const char *lines = "*",
	      unsigned int w = 0, unsigned int margins = 1,
	      Alignment align = ALIGN_LEFT, bool nowarn = true);

    /**
     * \brief Detailed constructor
     *
     * This contructor allows a complet customization of the BoxedText under contruction.
     *
     * \param topleftcorner      Top left corner string.
     * \param toprightcorner     Top right corner string.
     * \param middleleftcorner   Middle left corner string.
     * \param middlerightcorner  Middle right corner string.
     * \param bottomleftcorner   Bottom left corner string.
     * \param bottomrightcorner  Bottom right corner string.
     * \param upperline          Upper horizontal line string.
     * \param lowerline          Lower horizontal line string.
     * \param middleline         Middle horizontal line string.
     * \param leftline           Left vertical line string.
     * \param rightline          Right vertical line string.
     * \param totalwidth         Total width of the framed box (default: 0, which means autodetect
     *                           and use terminal number of columns).
     * \param totalheight        Total height of the framed box (default: 0, which means autodetect
     *                           and use terminal number of rows).
     * \param leftmargin         Left margin between the box border and the text (default: 1).
     * \param rightmargin        Right margin between the text and the box border (default: 1).
     * \param alignment          Default (global) text alignment inside the box (default: left align).
     * \param nowarn             Set to true to disable warnings (default: true).
     * \param interacts          Set to true to display interactively the content.
     * \param no_escape          Set to true to discard escape ansi codes.
     */
    BoxedText(const char *topleftcorner, const char *toprightcorner,
	      const char *middleleftcorner, const char *middlerightcorner,
	      const char *bottomleftcorner, const char *bottomrightcorner,
	      const char *upperline, const char *lowerline, const char *middleline,
	      const char *leftline, const char *rightline,
	      const unsigned int totalwidth = 0, const unsigned int totalheight = 0,
	      const unsigned int leftmargin = 1, const unsigned int rightmargin = 1,
	      const Alignment alignment = ALIGN_LEFT,
	      bool nowarn = true, bool interacts = true, bool no_escape = false);

    /**
     * \enum BorderType
     * \brief The different available borders (see setBorder).
     */
    enum BorderType {
      TOP_LEFT_CORNER     =    1, /**< Top left corner. */
      TOP_RIGHT_CORNER    =    2, /**< Top right corner. */
      MIDDLE_LEFT_CORNER  =    4, /**< Middle left corner. */
      MIDDLE_RIGHT_CORNER =    8, /**< Middle right corner. */
      BOTTOM_LEFT_CORNER  =   16, /**< Bottom left corner. */
      BOTTOM_RIGHT_CORNER =   32, /**< Bottom right corner. */
      ALL_CORNERS         =   63, /**< All corners. */
      UPPER_LINE          =   64, /**< Upper horizontal line. */
      LOWER_LINE          =  128, /**< Lower horizontal line. */
      MIDDLE_LINE         =  256, /**< Middle horizontal line. */
      HORIZONTAL_LINES    =  448, /**< Shortcut for all horizontal line. */
      LEFT_LINE           =  512, /**< Left vertical line. */
      RIGHT_LINE          = 1024, /**< Right vertical line. */
      VERTICAL_LINES      = 1536, /**< All vertical lines. */
      ALL_LINES           = 1984, /**< All lines. */
      ALL_TYPES           = 2047  /**< All the corners and the lines. */
    };

    /**
     * \brief Set given borders to the given string.
     *
     * \param c     Top string to use for the border (can be UTF-8).
     * \param type  Combination of BorderType to set the given border.
     */
    void setBorder(const char *c, unsigned int type);

    /**
     * \brief Get the text width of the box.
     *
     * \return This method returns the text width of the box.
     */
    unsigned int textWidth() const;

    /**
     * \brief Get the total width of the box.
     *
     * \return This method returns the total width of the box.
     */
    unsigned int totalWidth() const;

    /**
     * \brief Set the total width of the box.
     *
     * \param width Total width of the box (0 means autodetect and use terminal width).
     */
    void totalWidth(unsigned int width);

    /**
     * \brief Get the total height of the box.
     *
     * \return This method returns the total height of the box.
     */
    unsigned int totalHeight() const;

    /**
     * \brief Set the total height of the box.
     *
     * \param height Total height of the box (0 means autodetect and use terminal height).
     */
    void totalHeight(unsigned int height);

    /**
     * \brief Get the left margin length.
     *
     * \return This method returns the left margin length between the box border and the text.
     */
    unsigned int leftMargin() const;

    /**
     * \brief Set the left margin.
     *
     * \param width Left margin between the box border and the text.
     */
    void leftMargin(unsigned int width);

    /**
     * \brief Get the right margin length.
     *
     * \return This method returns the right margin length between the box border and the text.
     */
    unsigned int rightMargin() const;

    /**
     * \brief Set the right margin.
     *
     * \param width Right margin between the text and the box border.
     */
    void rightMargin(unsigned int width);

    /**
     * \brief Get the global alignment.
     *
     * \return This method returns the default global text alignment inside the box.
     */
    Alignment alignment() const;

    /**
     * \brief Set the global alignment.
     *
     * \param aln Default (global) text alignment inside the box.
     */
    void alignment(Alignment aln);

    /**
     * \brief Get information about warning display.
     *
     * \return This method returns true if warning are displayed, false otherwise.
     */
    bool doWarn() const;

    /**
     * \brief Set warning display behaviour.
     *
     * \param warn Set warning display to this value.
     * \return This method returns true if warning are displayed, false otherwise.
     */
    bool doWarn(const bool warn);

    /**
     * \brief Get information about interactive running mode.
     *
     * \return This method returns true if display is splitted according to screen height
     *         and user needs to interact, false otherwise.
     */
    bool interactive() const;

    /**
     * \brief Set interactive mode behaviour.
     *
     * \param interacts Set interactive mode to this value.
     * \return This method returns true if mode is interactive, false otherwise.
     */
    bool interactive(const bool interacts);

    /**
     * \brief Get information about escape codes display.
     *
     * \return This method returns true if escape codes are discard from the output, false otherwise.
     */
    bool noEscape() const;

    /**
     * \brief Set escape codes display discarded or not.
     *
     * \param no_escape Set the display of escape codes to this value.
     * \return This method returns true if escape codes are discarded, false otherwise.
     */
    bool noEscape(const bool no_escape);

    /**
     * \brief Fill the current object from given file
     *
     * \param filename An C string representing an existing and readable file.
     * \param dirs A vector of path to look for the given \p filename.
     *
     * The content of the file is appended to the content of the current object.
     */
    void readFile(const char *filename, const std::vector<std::string> &dirs = std::vector<std::string>());


    /**
     * \brief Replace all occurences the given pattern by the given text.
     *
     * \param pattern The pattern to substitute.
     * \param txt The replacement text.
     * \return This method returns the number of operated substitutions.
     */
    size_t replacePattern(const std::string &pattern, const std::string &txt);

    /**
     * \brief Get the accepted keywords.
     *
     * \return The accepted formatting keywords are returned as a vector of string.
     *
     * This method is primarily intended for users that don't want to read the documentation and
     * that prefer to get available keywords by programming.
     */
    static std::vector<std::string> getAvailableKeywords();

    /**
     * \brief Get the accepted color names.
     *
     * \return The accepted color names are returned as a vector of string.
     *
     * This method is primarily intended for users that don't want to read the documentation and
     * that prefer to get available color names by programming.
     */
    static std::vector<std::string> getAvailableColors();
  };

  /**
   * \fn std::ostream &operator<<(std::ostream &os, const BoxedText &bt);
   * \brief Pretty print the content of a BoxedText object.
   * \param[in,out] os The output stream to be filled.
   * \param[in] bt The Boxedtext object to display on os.
   * \return The modified output stream.
   */
  std::ostream &operator<<(std::ostream &os, const BoxedText &bt);

  /**
   * \fn unsigned int UTF8length(const char *str);
   * \brief Compute the length of an UTF8 encoded C string
   * \param[in] str C string that may contain UTF8 encoded chars.
   * \return The number of UTF8 chars composing the str C string.
   */
  size_t UTF8length(const char *str);

} /* End of DoccY name space */

#endif /*  __BOXEDTEXT_H__ */
// Local Variables:
// mode:c++
// End:
