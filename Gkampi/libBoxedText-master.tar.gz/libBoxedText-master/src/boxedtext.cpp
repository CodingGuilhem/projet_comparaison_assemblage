#include "boxedtext.h"
#include <sys/ioctl.h>
#include <iterator>
#include <stack>
#include <map>
#include <iostream>
#include <fstream>
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#ifdef DEBUG
#  define DBG(content) content
#else
#  define DBG(content)
#endif

using namespace std;
using namespace DoccY;

extern "C" {
  char *libBoxedTextVersion() {
    return (char*)PACKAGE_VERSION;
  }
}

static bool isBlank(const char c, const bool check_null = false) {
  return ((c == ' ') || (c == '\t') || (c == '\n') || (check_null && (c == '\0')));
}

vector<string> BoxedText::_keywords, BoxedText::_colors;
const size_t max_tag_length = 7;
const size_t max_tag_lookuplength = 30;

void BoxedText::initKeywords() {
  if (_keywords.empty()) {
    _keywords.push_back("hr");
    _keywords.push_back("p");
    _keywords.push_back("br");
    _keywords.push_back("center");
    _keywords.push_back("left");
    _keywords.push_back("right");
    _keywords.push_back("justify");
    _keywords.push_back("pre");
    _keywords.push_back("color");
    _keywords.push_back("b");
    _keywords.push_back("i");
    _keywords.push_back("u");
    _keywords.push_back("blink");
    _keywords.push_back("reverse");
  }
}

void BoxedText::initColors() {
  if (_colors.empty()) {
    _colors.push_back("black");
    _colors.push_back("red");
    _colors.push_back("green");
    _colors.push_back("yellow");
    _colors.push_back("blue");
    _colors.push_back("magenta");
    _colors.push_back("cyan");
    _colors.push_back("white");
  }
}
bool BoxedText::isValidTag(const char *tag, Alignment align) {
  bool found = false;
  if (tag && (*tag++ == '<')) {
    const vector<string> &kw = getAvailableKeywords();
    if (*tag == '/') {
      tag++;
    } else {
      if (align == PRINT_ASIS) {
	return false;
      }
    }
    vector<string>::const_iterator it = kw.begin();
    while (!found && (it != kw.end())) {
      if ((align != PRINT_ASIS) || (*it == "pre")) {
	size_t i = 0, n = it->length();
	// DBG(cerr << "Comparing tag to " << *it << endl);
	found = true;
	while (found && (i < n)) {
	  found = ((*it)[i] == *(tag+i));
	  i++;
	}
	// DBG(cerr << "Found is " << found << endl);
	if (found) {
	  // DBG(cerr << "Looking forward for closing braquet" << endl);
	  // DBG(cerr << "tag[i-1..i+2] = " << *(tag + i - 1) << *(tag + i) << *(tag + i + 1) << *(tag + i + 2) << endl);

	  if ((i < max_tag_lookuplength) && isBlank(*(tag + i))) {
	    // DBG(cerr << "Skipping parameters." << endl);
	    while ((*(tag + i) != '>') && (*(tag + i) != '\0')) {
	      i++;
	    }
	  }
	  found = (*(tag + i) == '>');
	}
      }
      ++it;
    }
  }
  // DBG(cerr << "Returning " << found << endl);
  return found;
}

vector<string> BoxedText::getAvailableKeywords() {
  initKeywords();
  return _keywords;
}

vector<string> BoxedText::getAvailableColors() {
  initColors();
  return _colors;
}

BoxedText::BoxedText(const char *corners, const char *lines,
		     unsigned int w, unsigned int margins,
		     BoxedText::Alignment align, bool nowarn) {
  init(corners, corners, corners, corners, corners, corners,
       lines, lines, lines, lines, lines,
       w, 0, margins, margins, align, nowarn, false, false);
}

BoxedText::BoxedText(const char *topleftcorner, const char *toprightcorner,
		     const char *middleleftcorner, const char *middlerightcorner,
		     const char *bottomleftcorner, const char *bottomrightcorner,
		     const char *upperline, const char *lowerline, const char *middleline,
		     const char *leftline, const char *rightline,
		     const unsigned int totalwidth, const unsigned int totalheight,
		     const unsigned int leftmargin, const unsigned int rightmargin,
		     const Alignment alignment, bool nowarn, bool interacts, bool no_escape) {
  init(topleftcorner, toprightcorner, middleleftcorner, middlerightcorner, bottomleftcorner, bottomrightcorner,
       upperline, lowerline, middleline, leftline, rightline,
       totalwidth, totalheight, leftmargin, rightmargin, alignment, nowarn, interacts, no_escape);
}

void BoxedText::init(const char *topleftcorner, const char *toprightcorner,
		     const char *middleleftcorner, const char *middlerightcorner,
		     const char *bottomleftcorner, const char *bottomrightcorner,
		     const char *upperline, const char *lowerline, const char *middleline,
		     const char *leftline, const char *rightline,
		     const unsigned int totalwidth,const unsigned int totalheight,
		     const unsigned int leftmargin, const unsigned int rightmargin,
		     const Alignment alignment, bool nowarn, bool interacts, bool no_escape) {
  _topleftcorner = topleftcorner;
  _toprightcorner = toprightcorner;
  _middleleftcorner = middleleftcorner;
  _middlerightcorner = middlerightcorner;
  _bottomleftcorner = bottomleftcorner;
  _bottomrightcorner = bottomrightcorner;
  _upperline = upperline;
  _lowerline = lowerline;
  _middleline = middleline;
  _leftline = leftline;
  _rightline= rightline;
  _totalwidth = totalwidth;
  _totalheight = totalheight > 1 ? totalheight - 1 : 0;
  _leftmargin = leftmargin;
  _rightmargin = rightmargin;
  _alignment = alignment;
  _nowarn = nowarn;
  _interacts = interacts;
  _no_escape = no_escape;
  if (!_totalwidth || !_totalheight) {
    struct winsize ws;
    if (ioctl(0, TIOCGWINSZ, &ws) != -1) {
      if (!_totalwidth) {
	_totalwidth = ws.ws_col;
      }
      if (!_totalheight) {
	_totalheight = ws.ws_row > 1 ? ws.ws_row - 1 : 0;
      }
    } else {
      if (!_totalwidth) {
	_totalwidth = 80;
      }
      if (!_totalheight) {
	_totalheight = 24;
      }
    }
  }
  while (_leftmargin
	 && _rightmargin
	 && (_leftmargin + _rightmargin > _totalwidth + 2)) {
    if (_leftmargin) _leftmargin--;
    if (_rightmargin) _rightmargin--;
  }
  initColors();
  initKeywords();
}

void BoxedText::setBorder(const char *c, const unsigned int type) {
  if (type & TOP_LEFT_CORNER) { _topleftcorner = c; }
  if (type & TOP_RIGHT_CORNER) { _toprightcorner = c; }
  if (type & MIDDLE_LEFT_CORNER) { _middleleftcorner = c; }
  if (type & MIDDLE_RIGHT_CORNER) { _middlerightcorner = c; }
  if (type & BOTTOM_LEFT_CORNER) { _bottomleftcorner = c; }
  if (type & BOTTOM_RIGHT_CORNER) { _bottomrightcorner = c; }
  if (type & UPPER_LINE) { _upperline = c; }
  if (type & LOWER_LINE) { _lowerline = c; }
  if (type & MIDDLE_LINE) { _middleline = c; }
  if (type & LEFT_LINE) { _leftline = c; }
  if (type & RIGHT_LINE) { _rightline = c; }
  if (!_nowarn && (type >= 2 * RIGHT_LINE)) {
    cerr << "BoxedText Warning: unknown border type (code "
	 << type << " is greater than " << (2 * RIGHT_LINE - 1)
	 << endl;
  }
}

unsigned int BoxedText::textWidth() const {
  return _totalwidth - _leftmargin - _rightmargin - UTF8length(_leftline) - UTF8length(_rightline);
}

unsigned int BoxedText::totalWidth() const {
  return _totalwidth;
}

void BoxedText::totalWidth(unsigned int width) {
  _totalwidth = width;
}

unsigned int BoxedText::totalHeight() const {
  return _totalheight;
}

void BoxedText::totalHeight(unsigned int height) {
  _totalheight = height > 1 ? height - 1 : 0;
}

unsigned int BoxedText::leftMargin() const {
  return _leftmargin;
}

void BoxedText::leftMargin(unsigned int margin) {
  _leftmargin = margin;
}

unsigned int BoxedText::rightMargin() const {
  return _rightmargin;
}

void BoxedText::rightMargin(unsigned int margin) {
  _rightmargin = margin;
}

BoxedText::Alignment BoxedText::alignment() const {
  return _alignment;
}

void BoxedText::alignment(BoxedText::Alignment align) {
  _alignment = align;
}

bool BoxedText::doWarn() const {
  return !_nowarn;
}

bool BoxedText::doWarn(const bool warn) {
  _nowarn = !warn;
  return _nowarn;
}

bool BoxedText::interactive() const {
  return _interacts;
}

bool BoxedText::interactive(const bool interacts) {
  _interacts = interacts;
  return _interacts;
}

bool BoxedText::noEscape() const {
  return _no_escape;
}

bool BoxedText::noEscape(const bool no_escape) {
  _no_escape = no_escape;
  return _no_escape;
}

void BoxedText::readFile(const char *filename, const vector<string> &dirs) {
  ifstream fd;
  vector<string> fullnames = dirs;
  bool ok = false;
  size_t i = 0;

  if (dirs.empty()) {
    fullnames.push_back("");
    fullnames.push_back(PACKAGE_DATADIR "/");
    /* These two directory are mostly for development purpose */
    fullnames.push_back("resources/");
    fullnames.push_back("../resources/");
  }
  while ((i < fullnames.size()) && !ok) {
    fullnames[i] += filename;
    fd.open(fullnames[i].c_str());
    DBG(cerr << "Trying to open '"<<fullnames[i]<<"'" << endl);
    if (!(ok = fd.good())) {
      fullnames[i] += ".btml";
      fd.open(fullnames[i].c_str());
      DBG(cerr << "Trying to open '"<<fullnames[i]<<"'" << endl);
      ok = fd.good();
    }
    i++;
  }
  if (!ok) {
    cerr << "BoxedText Error: Unable to open file '" << filename << "'." << endl;
  } else {
    copy(istreambuf_iterator<char>(fd),
	 istreambuf_iterator<char>(),
	 ostreambuf_iterator<char>(*this));
    fd.close();
  }
}

size_t BoxedText::replacePattern(const string &pattern, const string &txt) {
  string str = this->str();
  size_t cpt = 0, start = 0;
  while ((start = str.find(pattern, start)) != string::npos) {
    str.replace(start, pattern.length(), txt);
    cpt++;
  }
  this->str(str);
  seekp(0, ios_base::end);
  return cpt;
}

size_t DoccY::UTF8length(const char *str) {
  size_t nb = 0;
  char ch = *str;
  while (str && (ch != '\0')) {
    if (!(ch & 128)) {
      str++;
      ch = *str;
    } else {
      int octets=0;
      do {
	octets++;
	ch <<= 1;
      } while (ch & 128);
      str += octets;
      ch = *str;
    }
    nb++;
  }
  return nb;
}

#define make_width_var(var) size_t var ## _width = UTF8length(bt.var)
inline size_t max(size_t a, size_t b) {
  return (a > b ? a : b);
}

#define PressEnter()				      \
  if (bt._interacts && (nb_l++ == bt._totalheight)) {   \
    os << "Press enter to continue...";		      \
    while (cin.get() != '\n');			      \
    nb_l = 0;					      \
  }

ostream &DoccY::operator<<(ostream &os, const BoxedText &bt) {
  stack<BoxedText::Alignment> local_alignment;
  stack<int> fg_colors;
  stack<int> bg_colors;
  stack<string> open_tags;
  stack<string> temp_tags;
  fg_colors.push(9);
  bg_colors.push(9);
  local_alignment.push(bt._alignment);
  const string &str = bt.str();
  const char *ptr = str.c_str();
  unsigned int nb_l = 0;

  make_width_var(_topleftcorner);
  make_width_var(_toprightcorner);
  make_width_var(_middleleftcorner);
  make_width_var(_middlerightcorner);
  make_width_var(_bottomleftcorner);
  make_width_var(_bottomrightcorner);
  make_width_var(_leftline);
  make_width_var(_rightline);

  size_t maxleft = max(max(_topleftcorner_width, _leftline_width),
		       max(_middleleftcorner_width, _bottomleftcorner_width));
  size_t maxright = max(max(_toprightcorner_width, _rightline_width),
			max(_middlerightcorner_width, _bottomrightcorner_width));
  size_t width = bt._totalwidth - bt._leftmargin - bt._rightmargin - maxleft - maxright;

  PressEnter();
  os << (bt._no_escape ? "" : "\033[0m") << bt._topleftcorner;
  for (size_t i = _topleftcorner_width; i < bt._totalwidth - _toprightcorner_width; i++) {
    os << bt._upperline;
  }
  os << bt._toprightcorner << endl;
  int nbemptyline = (local_alignment.top() == BoxedText::PRINT_ASIS ? 0 : 2);
  while (ptr && (*ptr != '\0')) {
    // Compute nb of words to display on a given line and display them
    const char *start = NULL, *stop = NULL;
    bool skipline = true;
    size_t nb_words = 0;
    size_t nb_chars = 0;
    size_t nb_chars_in_cur_word = 0;
    const char *word_start = NULL;
    char last = '\0', last_printable = '\0';
    int meta = 0; /* 1 if in a opening meta keyword,
		     2 if in a closing meta keyword,
		     3 if in a opening meta parameter,
		     4 if in a closing meta parameter (for coding facilities),
		     -1 the following '<' char doesn't start a meta */
    const char* meta_start = NULL;
    string meta_keyword = ""; /* content of the current meta string */
    string meta_args = ""; /* content of the current meta string */

    // Skipping front spaces and other strange char codes in Formatting Mode
    while ((local_alignment.top() != BoxedText::PRINT_ASIS) && (*ptr != '\0') && ((unsigned char) *ptr <= ' ')) {
      DBG(cerr << "skipping: '"<< *ptr <<"'" <<endl);
      nbemptyline += (*(ptr++) == '\n');
    }
    if ((local_alignment.top() != BoxedText::PRINT_ASIS) && (*ptr != '\0') && (nbemptyline > 1)) {
      PressEnter();
      os << (bt._no_escape ? "" : "\033[0m") << bt._leftline;
      for (size_t i = 0; i < bt._leftmargin + maxleft - _leftline_width; i++) {
	os << ' ';
      }
      DBG(cerr << "prettyprinting... Tags: " << open_tags.size() << endl);
      if (!bt._no_escape) {
	while (!open_tags.empty()) {
	  stringstream code;
	  string tag = open_tags.top();
	  open_tags.pop();
	  temp_tags.push(tag);
	  int v = (tag == "b" ? 1 :
		   (tag == "i" ? 3 :
		    (tag == "u" ? 4 :
		     (tag == "blink" ? 5 :
		      (tag == "reverse" ? 7 : 0)))));
	  DBG(cerr << "tag: " << tag << " => code " << v << endl);
	  if (v) {
	    code << "\033[" << v << "m";
	  } else {
	    if (tag == "color") {
	      code << "\033[3" << fg_colors.top() << "m";
	      code << "\033[4" << bg_colors.top() << "m";
	      DBG(} else {
		cerr << "skipped" << endl);
	    }
	  }
	  os << code.str();
	}
	while (!temp_tags.empty()) {
	  open_tags.push(temp_tags.top());
	  temp_tags.pop();
	}
      }

      for (size_t i = 0; i < width; i++) {
	os << ' ';
      }
      os << (bt._no_escape ? "" : "\033[0m");
      for (size_t i = 0; i < bt._rightmargin + maxright - _rightline_width; i++) {
	os << ' ';
      }
      os << bt._rightline << endl;
    }
    nbemptyline = 0;
    start = ptr;
    // First step, computation...
    while (!stop && (*ptr != '\0')) {
      DBG(
	  cerr << "===\nBefore reading: '"<< *ptr << "'" <<endl
	  << "InWord: " << (word_start ? "yes" : "no") << " ["<< (void *) word_start << "]" << endl
	  << "Nb chars in current word = " << nb_chars_in_cur_word << endl
	  << "Nb Chars = " << nb_chars << endl
	  << "Nb Words = " << nb_words << endl
	  << "last char: '" << last << "'" << endl
	  << "last printable char: '" << last_printable << "'" << endl
	  << "meta = " << meta << endl
	  << "meta_keyword = '" << meta_keyword << "'" << endl
	  << "meta_args = '" << meta_args << "'" << endl
	  << "meta_start = '" << (void *) meta_start << "'" << endl
	  << "start = " << (void *) start << endl
	  << "stop = " << (void *) stop << endl
	  );
      if ((unsigned char) *ptr <= ' ') { // Non printable characters + spaces
	switch (*ptr) {
	case '\n':
	  if (meta <= 0) {
	    //nbemptyline++;
	    if (local_alignment.top() == BoxedText::PRINT_ASIS) {
	      stop = ptr + 1;
	    } else {
	      if (last == '\n') {
		stop = ptr - 1;
		nb_chars -= (*(ptr+1) != '\0');
	      }
	    }
	  }
	case ' ':
	case '\t':
	  if (meta <= 0) {
	    if ((local_alignment.top() == BoxedText::PRINT_ASIS) || word_start) {
	      word_start = NULL;
	      nb_chars_in_cur_word = 0;
	      nb_chars++;
	    }
	  } else {
	    if (meta < 3) {
	      meta += 2;
	    } else {
	      if (meta_args != "") {
		meta_args += ' ';
	      }
	    }
	  }
	  last_printable = *ptr;
	  break;
	case '\a':
	case '\b':
	case '\v':
	case '\f':
	case '\r':
	default:
	  if (!bt._nowarn) {
	    cerr << "BoxedText Warning: ignoring non printable character with ASCII code "
		 << (int) (*ptr) << "."
		 << endl;
	  }
	  break;
	}
      } else { // Printable and visible chars
	if (meta <= 0) {
	  meta = ((local_alignment.top() != BoxedText::PRINT_ASIS)
		  || (local_alignment.size() > 1)) && BoxedText::isValidTag(ptr, local_alignment.top());
	  if (meta <= 0) {
	    nbemptyline = 0;
	    if (!word_start) {
	      if (isBlank(last_printable, true)) {
		++nb_words;
		DBG(
		    } else {
		  cerr << "nb_words not incr because last_printable = " << last_printable << endl
		    );
	      }
	      word_start = ptr;
	    }
	    last_printable = *ptr;
	    nb_chars++;
	    nb_chars_in_cur_word++;
	    // Deal with UTF8 characters
 	    if (*ptr & 128) { // ch is UTF8
	      char ch = *ptr;
	      while (((ch <<= 1) & 128) && (*(++ptr) != '\0'));
	    }
	  } else {
	    meta_start = ptr;
	    word_start = ptr;
	  }
	} else {
	  if ((*ptr == '>') || (meta_keyword.length() > max_tag_length)) {
	    bool ok = true;
	    // Analyse meta_keyword and meta_args
	    if (meta_keyword == "pre") {
	      if (local_alignment.top() == BoxedText::PRINT_ASIS) {
		if ((local_alignment.size() == 1) || (meta % 2)) {
		  ok = false;
		} else {
		  stop = ptr + 1;
		}
	      } else {
		stop = ptr + 1;
	      }
	      if (ok && (meta_args != "") && !bt._nowarn) {
		cerr << "BoxedText Warning: the current tag '<" << meta_keyword
		     << ">' doesn't expect parameters (you provide '" << meta_args << "'). "
		     << "This extra information is ignored."
		     << endl;
	      }
	    } else {
	      DBG(cerr << "local_alignment.top() ["<<local_alignment.size()<<"]: "
		  << (local_alignment.top() == BoxedText::ALIGN_LEFT ? "LEFT" :
		      (local_alignment.top() == BoxedText::ALIGN_RIGHT ? "RIGHT" :
		       (local_alignment.top() == BoxedText::ALIGN_CENTER ? "CENTER" :
			(local_alignment.top() == BoxedText::ALIGN_JUSTIFY ? "JUSTIFY" :
			 (local_alignment.top() == BoxedText::PRINT_ASIS ? "ASIS" :
			  "UNKNOW"))))) << endl);
	      if (local_alignment.top() == BoxedText::PRINT_ASIS) {
		ok = false;
	      } else {
		if ((meta_keyword == "hr") || (meta_keyword == "br")) {
 		  if (last == '/') { // This is a self closing tag, setting it to meta = 1/3
 		    if (!(meta % 2)) {
 		      meta--;
 		    }
 		    DBG(cerr << "Here with meta = " << meta << endl);
 		  }
		  if (meta % 2) {
		    stop = ptr + 1;
		    nbemptyline += (meta_keyword == "br");
		    skipline = false;
		  }
		} else {
		  if ((meta_keyword == "p") || (meta_keyword == "center")
		      || (meta_keyword == "left")|| (meta_keyword == "right")
		      || (meta_keyword == "justify")) {
		    stop = ptr + 1;
		    if (!nbemptyline) {
		      nbemptyline += (meta_keyword == "p");
		    }
		  } else {
		    if ((meta_keyword == "color")
			|| (meta_keyword == "b") || (meta_keyword == "i") || (meta_keyword == "u")
			|| (meta_keyword == "blink") || (meta_keyword == "reverse")) {
		      // Nothing to do for the moment
		    } else {
		      ok = false;
		    }
		  }
		}
	      }
	    }
	    if (ok) {
	      if (!isBlank(*(ptr+1), true)) {
		word_start = NULL;
		nb_chars_in_cur_word = 0;
	      }
	      meta = 0;
	      meta_start = NULL;
	      DBG(cerr << "The tag '" << meta_keyword << "' was found!" << endl);
	    } else {
	      meta = -1;
	      ptr = meta_start - 1;
	      meta_start = NULL;
	      DBG(cerr << "The tag '" << meta_keyword << "' wasn't found!" << endl);
	    }
	    //word_start = NULL;
	    meta_keyword = meta_args = "";
	  } else {
	    if (meta < 3) { // We are in the keyword part of the meta
	      if ((meta == 1) && (last == '<') && (*ptr == '/')) {
		meta++; // This is a closing tag
	      } else {
		if ((*ptr != '/') || (*(ptr + 1) != '>')) {
		  meta_keyword += tolower(*ptr); // This is not a self closing tag
		}
	      }
	    } else {
	      if ((*ptr != '/') || (*(ptr + 1) != '>')) {
		meta_args += tolower(*ptr);
	      }
	    }
	  }
	}
      }
      last = *(ptr++);
      if ((nb_chars >= width) || (*ptr == '\0')) {
	if (word_start) {
	  if (isBlank(*ptr, true)) {
	    stop = ptr;
	    word_start = NULL;
	    nb_chars_in_cur_word = 0;
	  } else {
	    if (((local_alignment.top() != BoxedText::PRINT_ASIS) || (local_alignment.size() > 1)) && BoxedText::isValidTag(ptr, local_alignment.top())) {
	      stop = ptr;
	      word_start = NULL;
	      nb_chars_in_cur_word = 0;
	    } else {
	      nb_chars -= nb_chars_in_cur_word + 1; //(ptr - word_start + 1);
	      if (word_start < start) {
		cerr << __FILE__ << ":" << __LINE__
		     << ": In function " << __FUNCTION__ << ": "
		     << "BoxedText BUG: This should simply not happen!!!" << endl
		     << "Please contact " << PACKAGE_BUGREPORT << "." << endl;
	      } else {
		const char * tmp = start;
		while (isBlank(*tmp) && (tmp < word_start)) {
		  tmp++;
		}
		if (word_start == tmp) { //need to truncate the long long word...
		  start = tmp;
		  ptr = stop = start + width;
		  nb_chars = width;
		} else {
		  DBG(cerr << "ADJUST 1" << endl);
		  ptr = word_start;
		  stop = ptr - 1;
		  nb_chars += !isBlank(*stop);
		  DBG(cerr << "STOP is '" << *(stop - 1) << *(stop) << *(stop + 1) << "'" << endl);
		  while (isBlank(*stop)) {
		    stop--;
		  }
		  stop++;
		  if (!nb_words || (nb_words-- < 1)) {
		    cerr << __FILE__ << ":" << __LINE__
			 << ": In function " << __FUNCTION__ << ": "
			 << "BoxedText BUG: This should simply not happen!!!" << endl
			 << "Please contact " << PACKAGE_BUGREPORT << "." << endl;
		  }
		}
	      }
	    }
	  }
	} else {
	  if (local_alignment.top() != BoxedText::PRINT_ASIS) {
	    DBG(cerr << "ADJUST 2" << endl);
	    ptr--;
	    nb_chars -= isBlank(*ptr, true);
	    while (isBlank(*ptr)) {
	      ptr--;
	    }
	    stop = ptr + 1;
	  }
	}
      }
      DBG(cerr << "---\nAfter reading:" << endl
	  << "InWord: " << (word_start ? "yes" : "no") << " ["<< (void *) word_start << "]" << endl
	  << "Nb chars in current word = " << nb_chars_in_cur_word << endl
	  << "Nb Chars = " << nb_chars << endl
	  << "Nb Words = " << nb_words << endl
	  << "last char: '" << last << "'" << endl
	  << "last printable char: '" << last_printable << "'" << endl
	  << "meta = " << meta << endl
	  << "meta_keyword = '" << meta_keyword << "'" << endl
	  << "meta_args = '" << meta_args << "'" << endl
	  << "meta_start = '" << (void *) meta_start << "'" << endl
	  << "start = " << (void *) start << endl
	  << "stop = " << (void *) stop << endl);
    }
    skipline &= !nb_words && (local_alignment.top() != BoxedText::PRINT_ASIS);
    if (!stop) { // Thus ptr points to '\0'
      stop = ptr - 1;
    }

    // Second step, printing...
    DBG(cerr << "Number of chars to print: " << nb_chars << endl);
    nb_chars = width - nb_chars; // This is the number of extra spaces to add


    size_t justify_length = 0;
    size_t justify_jump = 0;
    size_t justify_extra = 0;
    bool   justify_dense = (nb_chars + 1 > nb_words);
    if ((nb_words - 1) && nb_chars) {
      if (justify_dense) {
	justify_length = nb_chars / (nb_words - 1);
	justify_extra = nb_chars % (nb_words - 1);
	justify_jump = 1;
      } else {
	justify_length = 1;
	justify_jump = (nb_words - 1) / nb_chars + 1;
	justify_extra = nb_chars - ((nb_words - 1) / (justify_jump));
      }
    }

    DBG(if (nb_words && !nbemptyline) {
	  cerr << "Need to add " << nb_chars << " extra spaces in " << nb_words - 1 << " inter-spaces" << endl
	       << "Each insert will be of length " << justify_length
	       << " at each " << justify_jump << " interspace" << endl
	       << " and by adding " <<justify_extra << " extra spaces" <<endl
	       << "Will pretty print:" << endl << "'";
	  for (const char *p = start; p != stop; p++) {
	    cerr << *p;
	  }
	  cerr << "'" << endl;
	}
	);

    if (!skipline) {
      PressEnter();
      os << (bt._no_escape ? "" : "\033[0m") << bt._leftline;
      for (size_t i = 0; i < bt._leftmargin + maxleft - _leftline_width; i++) {
	os << ' ';
      }
      DBG(cerr << "prettyprinting2... Tags: " << open_tags.size() << endl);
      if (!bt._no_escape) {
	while (!open_tags.empty()) {
	  stringstream code;
	  string tag = open_tags.top();
	  open_tags.pop();
	  temp_tags.push(tag);
	  int v = (tag == "b" ? 1 :
		   (tag == "i" ? 3 :
		    (tag == "u" ? 4 :
		     (tag == "blink" ? 5 :
		      (tag == "reverse" ? 7 : 0)))));
	  DBG(cerr << "tag: " << tag << " => code " << v << endl);
	  if (v) {
	    code << "\033[" << v << "m";
	  } else {
	    if (tag == "color") {
	      code << "\033[3" << fg_colors.top() << "m";
	      code << "\033[4" << bg_colors.top() << "m";
	      DBG(} else {
		cerr << "skipped" << endl);
	    }
	  }
	  os << code.str();
	}
	while (!temp_tags.empty()) {
	  open_tags.push(temp_tags.top());
	  temp_tags.pop();
	}
      }
    }
    ptr = start;
    if (!skipline) {
      if (local_alignment.top() == BoxedText::ALIGN_RIGHT) {
	while (nb_chars) {
	  --nb_chars;
	  os << ' ';
	}
      } else {
	if (local_alignment.top() == BoxedText::ALIGN_CENTER) {
	  nb_words = (nb_chars / 2) + (nb_chars % 2);
	  nb_chars /= 2;
	  while (nb_words) {
	    --nb_words;
	    os << ' ';
	  }
	}
      }
    }
    word_start = NULL;

    DBG(cerr << "After analysis, there is " << nb_words
	<< " words to print and it requires " << nb_chars
	<< " extra spaces to be added (from address "
	<< (void *) start << " to " << (void *) stop << ")"
	<< endl);
    last_printable = last = '\0';

    meta = 0;
    meta_start = NULL;
    meta_keyword = meta_args = "";
    DBG(cerr << "stop is '" << *stop << "'"<<endl);
    while ((*ptr != '\0') && (ptr != stop)) {
      if ((unsigned char) *ptr <= ' ') { // Non printable characters + space
	switch (*ptr) {
	case '\n':
	case ' ':
	case '\t':
	  if (meta <= 0) {
	    if ((local_alignment.top() == BoxedText::PRINT_ASIS) || word_start) {
	      word_start = NULL;
	      os << ' ';
	      if (nb_words) {
		--nb_words;
	      }
	      if ((local_alignment.top() == BoxedText::ALIGN_JUSTIFY)
		  && !nbemptyline && nb_chars
		  && (!(nb_words % justify_jump) || (nb_words == 1))) {
		if (nb_words == 1) {
		  while (nb_chars) {
		    --nb_chars;
		    os << ' ';
		  }
		} else {
		  for (size_t i = 0; i < justify_length; i++) {
		    --nb_chars;
		    os << ' ';
		  }
		  if (justify_extra) {
		    --nb_chars;
		    --justify_extra;
		    os << ' ';
		  }
		}
	      }
	    }
	  } else {
	    if (meta < 3) {
	      meta += 2;
	    } else {
	      if (meta_args != "") {
		meta_args += ' ';
	      }
	    }
	  }
	  break;
	case '\a':
	case '\b':
	case '\v':
	case '\f':
	case '\r':
	default:
	  break;
	}
      } else { // Printable chars
	if (meta <= 0) {
	  meta = ((local_alignment.top() != BoxedText::PRINT_ASIS) || (local_alignment.size() > 1)) && BoxedText::isValidTag(ptr, local_alignment.top());
	  if (meta <= 0) {
	    word_start = ptr;
	    // Deal with UTF8 characters
	    os << *ptr;
 	    if (*ptr & 128) { // ch is UTF8
	      char ch = *ptr;
	      while (((ch <<= 1) & 128) && (*(++ptr) != '\0')) {
		os << *ptr;
	      }
	    }
	  } else {
	    meta_start = ptr;
	    word_start = ptr;
	  }
	} else {
	  if ((*ptr == '>') || (meta_keyword.length() > max_tag_length)) {
	    bool ok = true;
	    bool ignore_tag_warning = false;
	    // Analyse meta_keyword and meta_args
	    if (meta_keyword == "pre") {
	      if (local_alignment.top() == BoxedText::PRINT_ASIS) {
		if ((local_alignment.size() == 1) || (meta % 2)) {
		  ok = false;
		} else {
		  stop = ptr + 1;
		}
	      } else {
		stop = ptr + 1;
	      }
	      if (ok && (meta_args != "") && !bt._nowarn) {
		cerr << "BoxedText Warning: the current tag '<" << meta_keyword
		     << ">' doesn't expect parameters (you provide '" << meta_args << "'). "
		     << "This extra information is ignored."
		     << endl;
	      }
	    } else {
	      if (local_alignment.top() == BoxedText::PRINT_ASIS) {
		ok = false;
	      } else {
		if ((meta_keyword == "hr") || (meta_keyword == "br")) {
		  ignore_tag_warning = true;
 		  if (last == '/') { // This is a self closing tag, setting it to meta = 1/3
 		    if (!(meta % 2)) {
 		      meta--;
 		    }
 		  }
		} else {
		  if ((meta_keyword == "p") || (meta_keyword == "center")
		      || (meta_keyword == "left")|| (meta_keyword == "right")
		      || (meta_keyword == "justify")) {
		    if ((meta_args != "") && !bt._nowarn) {
		      cerr << "BoxedText Warning: the current tag '<" << meta_keyword
			   << ">' doesn't expect parameters (you provide '" << meta_args << "'). "
			   << "This extra information is ignored."
			   << endl;
		    }
		  } else {
		    if (meta_keyword == "color") {
		      if (meta % 2) {
			ok = false;
			size_t pos = meta_args.find("fg=");
			if (pos != string::npos) {
			  DBG(cerr << "Coloring foreground. Pos of 'fg=' in " << meta_args << " is " << pos << endl);
			  ok = true;
			  size_t color_code = 0;
			  while ((color_code < bt._colors.size())
				 && (meta_args.compare(pos+3, bt._colors[color_code].length(), bt._colors[color_code]))) {
			    color_code++;
			  }
			  if ((ok &= (color_code < bt._colors.size()))) {
			    if (!bt._no_escape) {
			      stringstream code;
			      code << "\033[3" << color_code << "m";
			      os << code.str();
			    }
			    DBG(cerr << "Pushing FG " << color_code << endl);
			    fg_colors.push(color_code);
			  }
			} else {
			  if (fg_colors.empty()) {
			    fg_colors.push(9);
			  } else {
			    DBG(cerr << "Pushing FG " << fg_colors.top() << endl);
			    fg_colors.push(fg_colors.top());
			  }
			}
			pos = meta_args.find("bg=");
			if (pos != string::npos) {
			  DBG(cerr << "Coloring background. Pos of 'bg=' in " << meta_args << " is " << pos << endl);
			  ok = true;
			  size_t color_code = 0;
			  while ((color_code < bt._colors.size())
				 && (meta_args.compare(pos+3, bt._colors[color_code].length(), bt._colors[color_code]))) {
			    color_code++;
			  }
			  if ((ok &= color_code < bt._colors.size())) {
			    if (!bt._no_escape) {
			      stringstream code;
			      code << "\033[4" << color_code << "m";
			      os << code.str();
			    }
			    bg_colors.push(color_code);
			  }
			} else {
			  if (bg_colors.empty()) {
			    bg_colors.push(9);
			  } else {
			    bg_colors.push(bg_colors.top());
			  }
			}
			if (!ok) {
			  fg_colors.pop();
			  bg_colors.pop();
			  if (!bt._nowarn) {
			    cerr << "BoxedText Warning: the current tag '<" << meta_keyword
				 << ">' expect at least one key=value parameter." << endl
				 << "Available keys are 'fg' or 'bg' and authorized values are:" << endl;
			    for (size_t i = 0; i < bt._colors.size(); i++) {
			      cerr << "- " << bt._colors[i] << endl;
			    }
			    cerr << "This TAG is just ignored."
				 << endl;
			  }
			}
		      } else {
			if ((meta_args != "") && !bt._nowarn) {
			  cerr << "BoxedText Warning: the current tag '<" << meta_keyword
			       << ">' doesn't expect parameters (you provide '" << meta_args << "'). "
			       << "This extra information is ignored."
			       << endl;
			}
			if (fg_colors.empty() && !bt._nowarn) {
			  cerr << "BoxedText Warning: No foreground color." << endl;
			} else {
			  fg_colors.pop();
			  if (!bt._no_escape) {
			    stringstream code;
			    code << "\033[3" << (fg_colors.empty() ? 9 : fg_colors.top()) << "m";
			    os << code.str();
			  }
			}
			if (bg_colors.empty() && !bt._nowarn) {
			  cerr << "BoxedText Warning: No background color." << endl;
			} else {
			  bg_colors.pop();
			  if (!bt._no_escape) {
			    stringstream code;
			    code << "\033[4" << (bg_colors.empty() ? 9 : bg_colors.top()) << "m";
			    os << code.str();
			  }
			}
		      }
		      ok = true;
		    } else {
		      if ((meta_keyword == "b") || (meta_keyword == "i") || (meta_keyword == "u")
			  || (meta_keyword == "blink") || (meta_keyword == "reverse")) {
			if ((meta_args != "") && !bt._nowarn) {
			  cerr << "BoxedText Warning: the current tag '<" << meta_keyword
			       << ">' doesn't expect parameters (you provide '" << meta_args << "'). "
			       << "This extra information is ignored."
			       << endl;
			}
			if (!bt._no_escape) {
			  stringstream code;
			  DBG(cerr << "Setting code for '" << meta_keyword << "' to "
			      << ((meta % 2) ? "" : "2")
			      << ((meta_keyword == "b") ? 2 - (meta % 2) :
                                  ((meta_keyword == "i") ? 3 :
                                   ((meta_keyword == "u") ? 4 :
                                    ((meta_keyword == "blink") ? 5 : 7))))
			      << "m" << endl);
			  code << "\033["
			       << ((meta % 2) ? "" : "2")
			       << ((meta_keyword == "b") ? 2 - (meta % 2) :
                                    ((meta_keyword == "i") ? 3 :
                                      ((meta_keyword == "u") ? 4 :
                                        ((meta_keyword == "blink") ? 5 : 7))))
			       << "m";
			  os << code.str();
			}
		      } else {
			ok = false;
		      }
		    }
		  }
		}
	      }
	    }
	    DBG(cerr << "Stack contains " << open_tags.size() << " opened tags";
		if (!open_tags.empty()) {
		  cerr << " (top: " << open_tags.top() << ")";
		}
		cerr <<"." << endl);
	    if (ok) {
	      DBG(
		  cerr << "The tag '" << meta_keyword << "' was found!" << endl
		  << "=== meta = " << meta << endl
		  << "=== meta_keyword = '" << meta_keyword << "'" << endl
		  << "=== meta_args = '" << meta_args << "'" << endl
		  << "=== meta_start = '" << (void *) meta_start << "'" << endl);
	      if (meta % 2) {
		open_tags.push(meta_keyword);
	      } else {
		if (!open_tags.empty()) {
		  string tmp = meta_keyword;
		  tmp[0] = toupper(tmp[0]);
		  if ((open_tags.top() == meta_keyword) || (open_tags.top() == tmp)) {
		    DBG(cerr << "Poping stack header " << open_tags.top() << "."
			<< " (Poping " << meta_keyword << ")" << endl);
		    open_tags.pop();
		  } else {
		    if ((meta_keyword != "hr") && (meta_keyword != "br") && !bt._nowarn) {
		      cerr << "BoxedText Warning: the current tag '<" << meta_keyword
			   << ">' doesn't close the opened '" << open_tags.top() << "' tag. "
			   << "This tag is ignored."
			   << endl;
		    }
		  }
		} else {
		  if (!ignore_tag_warning && !bt._nowarn) {
		    cerr << "BoxedText Warning: the current tag '<" << meta_keyword
			 << ">' closes an unopened tag. "
			 << "This tag is ignored."
			 << endl;
		  }
		}
	      }
	      meta = 0;
	      meta_start = NULL;
	      if (!isBlank(*(ptr+1), true)) {
		word_start = NULL;
	      }
	    } else {
	      DBG(cerr << "The tag '" << meta_keyword << "' wasn't found!" << endl);
	      meta = -1;
	      ptr = meta_start - 1;
	      meta_start = NULL;
	    }
	    //word_start = NULL;
	    meta_keyword = meta_args = "";
	    DBG(cerr << "Now, Stack contains " << open_tags.size() << " opened tags";
		if (!open_tags.empty()) {
		  cerr << " (top: " << open_tags.top() << ")";
		}
		cerr <<"." << endl);
	  } else {
	    if (meta < 3) { // We are in the keyword part of the meta
	      if ((meta == 1) && (last == '<') && (*ptr == '/')) {
		meta++; // This is a closing tag
	      } else {
		if ((*ptr != '/') || (*(ptr + 1) != '>')) {
		  meta_keyword += tolower(*ptr); // This is not a self closing tag
		}
	      }
	    } else {
	      if ((*ptr != '/') || (*(ptr + 1) != '>')) {
		meta_args += tolower(*ptr);
	      }
	    }
	  }
	}
      }
      last = *(ptr++);
      if (meta <= 0) {
	last_printable = last;
      }
      if ((ptr == stop) && (meta > 0)) {
	meta = -1;
	ptr = meta_start;
	meta_start = NULL;
	if (!isBlank(*(ptr+1), true)) {
	  word_start = NULL;
	}
	meta_keyword = meta_args = "";
      }
    }


    if (!skipline) {
      if ((local_alignment.top() == BoxedText::PRINT_ASIS)
	  || ((local_alignment.top() == BoxedText::ALIGN_JUSTIFY) && ((nb_words <= 1) || nbemptyline))
	  || (local_alignment.top() == BoxedText::ALIGN_LEFT)
	  || (local_alignment.top() == BoxedText::ALIGN_CENTER)) {
	while (nb_chars) {
	  --nb_chars;
	  os << ' ';
	}
      }
      os << (bt._no_escape ? "" : "\033[0m");
      for (size_t i = 0; i < bt._rightmargin + maxright - _rightline_width; i++) {
	os << ' ';
      }
      os << bt._rightline;
      os << endl;
    }

    DBG(cerr << "Before::Tags.size():" << open_tags.size() << endl);
    size_t nb_aligns = 1, nb_colors = 1;
    while (!open_tags.empty()) {
      meta_keyword = open_tags.top();
      open_tags.pop();
      temp_tags.push(meta_keyword);
      if (meta_keyword == "hr") {
	PressEnter();
	os << (bt._no_escape ? "" : "\033[0m") << bt._middleleftcorner;
	for (size_t i = _middleleftcorner_width; i < bt._totalwidth - _middlerightcorner_width; i++) {
	  os << bt._middleline;
	}
	os << bt._middlerightcorner;
	os << endl;
	temp_tags.pop();
	DBG(cerr << "Poping stack header " << meta_keyword << ".");
      } else if (meta_keyword == "p") {
	nbemptyline = 0;
	temp_tags.pop();
	temp_tags.push("P");
      } else if (meta_keyword == "br") {
	DBG(cerr << "Poping stack header " << meta_keyword << ".");
	nbemptyline = 0;
	temp_tags.pop();
      } else if (meta_keyword == "center") {
	nb_aligns++;
	local_alignment.push(BoxedText::ALIGN_CENTER);
      } else if (meta_keyword == "left") {
	nb_aligns++;
	local_alignment.push(BoxedText::ALIGN_LEFT);
      } else if (meta_keyword == "right") {
	nb_aligns++;
	local_alignment.push(BoxedText::ALIGN_RIGHT);
      } else if (meta_keyword == "justify") {
	nb_aligns++;
	local_alignment.push(BoxedText::ALIGN_JUSTIFY);
      } else if (meta_keyword == "pre") {
	nb_aligns++;
	local_alignment.push(BoxedText::PRINT_ASIS);
      } else if (meta_keyword == "color") {
	++nb_colors;
	DBG(cerr << "And " << nb_colors << "..." << endl);
      }
    }
    while (local_alignment.size() > nb_aligns) {
      local_alignment.pop();
    }
    while (bg_colors.size() > nb_colors) {
      if (!bt._nowarn) {
	cerr << "BoxedText Warning: too much stacked background colors ["
	     << bg_colors.size() << " > " << nb_colors << "] "
	     << "(removing " << bg_colors.top() << ")." << endl;
      }
      bg_colors.pop();
    }
    while (fg_colors.size() > nb_colors) {
      if (!bt._nowarn) {
	cerr << "BoxedText Warning: too much stacked foreground colors ["
	     << fg_colors.size() << " > " << nb_colors << "] "
	     << "(removing " << fg_colors.top() << ")." << endl;
      }
      fg_colors.pop();
    }

    while (!temp_tags.empty()) {
      open_tags.push(temp_tags.top());
      temp_tags.pop();
    }
    DBG(cerr << "After::Tags.size():" << open_tags.size() << endl);
  }
  if (local_alignment.top() != BoxedText::PRINT_ASIS) {
    PressEnter();
    os << bt._leftline;
    for (size_t i = _leftline_width; i < bt._totalwidth - _rightline_width; i++) {
      os << ' ';
    }
    os << bt._rightline << endl;
  }
  os << bt._bottomleftcorner;
  for (size_t i = _bottomleftcorner_width; i < bt._totalwidth - _bottomrightcorner_width; i++) {
    os << bt._lowerline;
  }
  os << bt._bottomrightcorner << endl;
  return os;
}
