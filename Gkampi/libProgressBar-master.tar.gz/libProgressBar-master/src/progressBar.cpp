/******************************************************************************
*                                                                             *
* Copyright © 2007      -- Université de Antilles et de la Guyane             *
* Copyright © 2007-2008 -- Institut National de Recherche en Informatique et  *
*                          en Automatique                                     *
* Copyright © 2008-2023 -- LIRMM/CNRS/UM                                      *
*                          (Laboratoire d'Informatique, de Robotique et de    *
*                          Microélectronique de Montpellier /                 *
*                          Centre National de la Recherche Scientifique /     *
*                          Université de Montpellier)                         *
*                                                                             *
*  Auteurs/Authors: Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  Programmeurs/Programmers:                                                  *
*                   Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  -------------------------------------------------------------------------  *
*                                                                             *
* This File (which initially comes from StatiSTARS) is part of the C++        *
* ProgressBar library.                                                        *
*                                                                             *
* This library is free software; you can redistribute it and/or modify it     *
* under the terms of the GNU Library General Public License as published by   *
* the Free Software Foundation; either version 2 of the License, or (at your  *
* option) any later version.                                                  *
*                                                                             *
* This library is distributed in the hope that it will be useful, but WITHOUT *
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or       *
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public       *
* License for more details.                                                   *
*                                                                             *
* You should have received a copy of the GNU Library General Public License   *
* along with this library; if not, write:                                     *
*                                                                             *
*                    the Free Software Foundation, Inc.,                      *
*                    59 Temple Place - Suite 330,                             *
*                    Boston, MA  02111-1307, USA.                             *
*                                                                             *
******************************************************************************/
#include "progressBar.h"
#include <iomanip>
#include <config.h>
#include <sstream>
#include <ctime>
#include <cstring>

using namespace DoccY;
using namespace std;

extern "C" {
  char *libProgressBarVersion() {
    return (char*)PACKAGE_VERSION;
  }
}

void ProgressBar::ShowPercent() {
  display |= SHOW_PERCENTS;
} /* Fin ShowPercent */

void ProgressBar::HidePercent() {
  display &= ~uint8_t(SHOW_PERCENTS);
} /* Fin HidePercent */

void ProgressBar::ShowTime() {
  display |= SHOW_TIME;
} /* Fin ShowTime */

void ProgressBar::HideTime() {
  display &= ~uint8_t(SHOW_TIME);
} /* Fin HideTime */


double ProgressBar::GetTime() const {
  struct timeval now;
  double res;
  gettimeofday(&now, NULL);
  res = now.tv_sec - start.tv_sec;
  res += now.tv_usec / 1000000.;
  res -= start.tv_usec / 1000000.;
  return res;
} /* Fin GetTime */

void ProgressBar::AddTime(double sec) {
  struct timeval delta;
  delta.tv_sec = int(sec);
  delta.tv_usec = int(sec*1000000) % 1000000;
  timersub(&start, &delta, &start);
}

size_t ProgressBar::GetMaxVal() const {
  return max_val;
}

size_t ProgressBar::GetCurVal() const {
  return val;
}

void ProgressBar::Reset() {
  val = 0;
  gettimeofday(&start, NULL);
  last_update = 0;
} /* Fin Reset */

void ProgressBar::SetVal(size_t v, bool update) {
  val = min(v, max_val);
  if (update) {
    this->update();
  } /* Fin Si */
} /* Fin SetVal */

void ProgressBar::Step(bool update) {
  val = min(val+1, max_val);
  if (update) {
    this->update();
  } /* Fin Si */
} /* Fin Step */

ProgressBar::ProgressBar(const string &t, const size_t m, const size_t w, ostream &os, double start):
  symbol('='), delim1('['), delim2(']'), title(t), val(0), max_val(m),
  width(w), output(os),
  start(), last_update(0),
  refresh_delay(0), display(SHOW_PERCENTS), subpb(0) {
  gettimeofday(&(this->start), NULL);
  AddTime(start);
} /* Fin ProgressBar */

ProgressBar::ProgressBar(const char s, const char d1, const char d2, const string &t,
			 size_t v, const size_t m, const size_t w,
			 ostream &os, double start, double delay):
  symbol(s), delim1(d1), delim2(d2), title(t), val(min(v, m)), max_val(m),
  width(w), output(os),
  start(), last_update(0),
  refresh_delay(delay), display(SHOW_PERCENTS), subpb(0) {
  gettimeofday(&(this->start), NULL);
  AddTime(start);
} /* Fin ProgressBar */

ProgressBar::~ProgressBar() {
} /* Fin ~ProgressBar */


void ProgressBar::setTitle(const string &t) {
  title = t;
}

void ProgressBar::setCursorAtBegin() const {
  stringstream code;
  code << "\033[" << (subpb + 1) << "A";
  output << endl << code.str(); // Add a new line, then move cursor up
}

void ProgressBar::setCursorAtEnd() const {
  stringstream code;              // Ansi escape code to move the cursor
  code << "\033[" << width << "C"; // to 'width' positions to the right
  if (subpb) {
    code << "\033[" << subpb << "B"; // then subpb line(s) down
  }
  setCursorAtBegin();
  output << code.str();
}

void ProgressBar::setRefreshDelay(double delay) {
  refresh_delay = delay;
}

void ProgressBar::update(bool force) const {
  size_t lg;
  size_t v;
  stringstream tps;
  double delay = GetTime() - last_update;
  if (last_update > 0.000001) {
    if (!force && (delay < refresh_delay)) {
      return;
    }
  }
  last_update += delay;
  setCursorAtBegin();
  if (display & SHOW_PERCENTS) {
    tps << setw(4) << setfill(' ') << val * 100 / max_val << " %";
  } /* Fin Si */
  if (display & SHOW_TIME) {
    double temps = GetTime();
    if (display & SHOW_PERCENTS) {
      tps << " (";
    } else {
      tps << " ";
    }
    if (temps < 60.0) {
      tps.precision((temps < 10.0)?2:1);
      tps.setf(stringstream::fixed,stringstream::floatfield);
      tps << temps << "s";
    } else {
      tps.precision(0);
      if (temps < 3600.0) {
	tps << int(temps)/60 << "m"
	    << setfill('0') << setw(2) << int(temps)%60;
      } else {
	if (temps < 86400.0) {
	  tps << int(temps)/3600 << "h"
	      << setfill('0') << setw(2) << int(temps)%3600/60;
	} else {
	  tps << int(temps)/86400 << "d"
	      << setfill('0') << setw(2) << int(temps)%86400/3600;
	} /* Fin Si */
      } /* Fin Si */
    } /* Fin Si */
    if (display & SHOW_PERCENTS) {
      tps << ")";
    }
  } /* Fin Si */
  lg = width - title.size() - 4 - tps.str().length();
  v = val * lg / max_val;
  output << title << " " << delim1;
  if (v) {
    output << setw(v) << setfill(symbol) << symbol;
  } /* Fin Si */
  output << setw(lg - v + 1) << setfill(' ') << delim2;
  output << tps.str() << flush;
  setCursorAtEnd();
} /* Fin update */

void ProgressBar::clear() const {
  setCursorAtBegin();
  output << "\033[2K" << flush;
  // CSI n K code erases part of the line.
  // If n is zero (or missing), clear from cursor to the end of the line.
  // If n is one, clear from cursor to beginning of the line.
  // If n is two, clear entire line. Cursor position does not change.
} /* Fin clear */

void ProgressBar::StartSubProgressBar() {
  setCursorAtBegin();
  stringstream code;
  code << "\033[" << ++subpb << "B";
  output << code.str();
  // Move the cursor to the beginning of line, then subpb line(s) down
}

void ProgressBar::EndSubProgressBar() {
  if (!subpb) {
    throw "Error: There is too much sub progress bar ending!!!";
  }
  subpb--;
  setCursorAtEnd();
}
