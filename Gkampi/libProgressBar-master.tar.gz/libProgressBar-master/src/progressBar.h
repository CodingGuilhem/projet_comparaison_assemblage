/******************************************************************************
*                                                                             *
* Copyright © 2007      -- Université de Antilles et de la Guyane             *
* Copyright © 2007-2008 -- Institut National de Recherche en Informatique et  *
*                          en Automatique                                     *
* Copyright © 2008-2023 -- LIRMM/CNRS/UM                                      *
*                          (Laboratoire d'Informatique, de Robotique et de    *
*                          Microélectronique de Montpellier /                 *
*                          Centre National de la Recherche Scientifique /     *
*                          Université de Montpellier)                         *
*                                                                             *
*  Auteurs/Authors: Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  Programmeurs/Programmers:                                                  *
*                   Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  -------------------------------------------------------------------------  *
*                                                                             *
* This File (which initially comes from StatiSTARS) is part of the C++        *
* ProgressBar library.                                                        *
*                                                                             *
* This library is free software; you can redistribute it and/or modify it     *
* under the terms of the GNU Library General Public License as published by   *
* the Free Software Foundation; either version 2 of the License, or (at your  *
* option) any later version.                                                  *
*                                                                             *
* This library is distributed in the hope that it will be useful, but WITHOUT *
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or       *
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public       *
* License for more details.                                                   *
*                                                                             *
* You should have received a copy of the GNU Library General Public License   *
* along with this library; if not, write:                                     *
*                                                                             *
*                    the Free Software Foundation, Inc.,                      *
*                    59 Temple Place - Suite 330,                             *
*                    Boston, MA  02111-1307, USA.                             *
*                                                                             *
******************************************************************************/
#ifndef __PROGRESSBAR_H
#define __PROGRESSBAR_H

/**
 * \mainpage
 *
 * \brief A C++ class to manage... progress bars.
 *
 * \author By DoccY <alban.mancheron@lirmm.fr>
 *
 * \copyright GNU Library General Public License
 *
 *     © 2007      -- Université de Antilles et de la Guyane
 *     © 2007-2008 -- Institut National de Recherche en Informatique et
 *                    en Automatique
 *     © 2008-2023 -- LIRMM/CNRS/UM
 *                    (Laboratoire d'Informatique, de Robotique et de
 *                    Microélectronique de Montpellier /
 *                    Centre National de la Recherche Scientifique /
 *                    Université de Montpellier)
 *
 */

/*
 * \file      progressBar.h
 *
 * \brief A C++ class to manage... progress bars.
 *
 * \author By DoccY <alban.mancheron@lirmm.fr>
 *
 * \copyright GNU Library General Public License
 *
 *     © 2007      -- Université de Antilles et de la Guyane
 *     © 2007-2008 -- Institut National de Recherche en Informatique et
 *                    en Automatique
 *     © 2008-2023 -- LIRMM/CNRS/UM
 *                    (Laboratoire d'Informatique, de Robotique et de
 *                    Microélectronique de Montpellier /
 *                    Centre National de la Recherche Scientifique /
 *                    Université de Montpellier)
 */

#include <iostream>
#include <string>
#include <sys/time.h>
#include <stdint.h>

/**
 * \namespace DoccY
 * For my personal convenience, I have decided to put all my C++ contributions
 * (at this time, it is the only one...) in this namespace.
 */
namespace DoccY {

  extern "C" {
    /**
     * One can use this function to test the library availability
     */
    char *libProgressBarVersion();
  }

  /**
   * Class ProgressBar.
   * \brief A C++ class to manage... progress bars.
   *
   * \author By DoccY <alban.mancheron@lirmm.fr>
   *
   * \copyright GNU Library General Public License
   *
   *     © 2007      -- Université de Antilles et de la Guyane
   *     © 2007-2008 -- Institut National de Recherche en Informatique et
   *                    en Automatique
   *     © 2008-2023 -- LIRMM/CNRS/UM
   *                    (Laboratoire d'Informatique, de Robotique et de
   *                    Microélectronique de Montpellier /
   *                    Centre National de la Recherche Scientifique /
   *                    Université de Montpellier)
   */
  class ProgressBar {

  private:

    /**
     * Symbol used for show the progression (default: '=').
     */
    const char symbol;

    /**
     * Starting delimiter (default: '[').
     */
    const char delim1;

    /**
     * Ending delimiter (default: ']').
     */
    const char delim2;

    /**
     * ProgressBar Title.
     */
    std::string title;

    /**
     * Current value of the process.
     */
    size_t val;

    /**
     * Max value (at the end of the process).
     */
    const size_t max_val;

    /**
     * Width of the progress bar.
     * This parameter must be large enough to write the title
     * and the optional time and percents.
     * \see display
     */
    const size_t width;

    /**
     * Output stream to display the progress bar.
     */
    std::ostream &output;

    /**
     * Starting time of the process.
     */
    struct timeval start;

    /**
     * Last update clock.
     */
    mutable double last_update;

    /**
     * Minimum refresh delay between updates (default to 0.01).
     */
    double refresh_delay;

    /**
     * constant values for masking/setting display attribute.
     * \see display
     */
    enum {
      SHOW_PERCENTS = 1,
      SHOW_TIME = 2
    };
    /**
     * Optional informations to display:
     * if (display & SHOW_PERCENTS), then show percents;
     * if (display & SHOW_TIME), then show consumed time.
     */
    uint8_t display;

    /**
     * Number of sub progress bars to print
     */
    size_t subpb;

  public:
    /**
     * Constructor (standard)
     * \param t ProgressBar title.
     * \param m Max value at the end of the process.
     * \param w Width of the Progress Bar.
     * \param os Output stream to display the progress bar (default: ios::cerr).
     * \param start Set starting time to this value in seconds (default: 0).
     * \see title, max_val, width, output, start
     */
    ProgressBar(const std::string &t, const size_t m, const size_t w, std::ostream &os = std::cerr, double start = 0);

    /**
     * Constructor (custom)
     * \param s Symbol used for show the progression (default: '=').
     * \param d1 Starting delimiter (default: '[').
     * \param d2 Ending delimiter (default: '[').
     * \param t ProgressBar title (default: "ProgressBar").
     * \param v Initial value at the begining of the process (default: 0).
     * \param m Max value at the end of the process (default: 100).
     *
     * \param w Width of the Progress Bar (default: 80).
     * \param os Output stream to display the progress bar (default: ios::cerr).
     * \param start Set starting time to this value in seconds (default: 0).
     * \param delay Set the minimum refresh delay between display updates in seconds (default: 0.01).
     * \see symbol, delim1, delim2, title, val, max_val, width, output
     */
    ProgressBar(const char s = '=', const char d1 = '[', const char d2 = ']',
		const std::string &t = "ProgressBar",
		size_t v = 0, const size_t m = 100, const size_t w = 80,
		std::ostream &os = std::cerr, double start = 0, double delay = 0.01);

    /**
     * Destructor
     */
    ~ProgressBar();

    /**
     * Enable percentage display.
     * \see display
     */
    void ShowPercent();

    /**
     * Disable percentage display.
     * \see display
     */
    void HidePercent();

    /**
     * Enable consumed time display.
     * \see display
     */
    void ShowTime();

    /**
     * Disable consumed time display.
     * \see display
     */
    void HideTime();

    /**
     * Get consumed time in seconds.
     * \see start
     */
    double GetTime() const;

    /**
     * Add sec seconds to expanded time.
     * \see start
     */
    void AddTime(double sec);

    /**
     * Get Max value.
     * \see max_val
     */
    size_t GetMaxVal() const;

    /**
     * Get Current value.
     * \see val
     */
    size_t GetCurVal() const;

    /**
     * Reset the progress bar.
     * \see val, start
     */
    void Reset();

    /**
     * Set the current value of the process.
     * \param v The current value.
     * \param update Refresh the progress bar display.
     * \see val, max_val, refresh_delay, setRefreshDelay(), update()
     */
    void SetVal(size_t v, bool update = false);

    /**
     * Increment by one the current value of the process.
     * \param update Refresh the progress bar display.
     * \see val, max_val, refresh_delay, setRefreshDelay(), update()
     */
    void Step(bool update = true);

    /**
     * Set the progress bar title
     * \param t ProgressBar title.
     * \see title
     */
    void setTitle(const std::string &t);

    /**
     * Go to the begin of progressbar.
     */
    void setCursorAtBegin() const;

    /**
     * Go to the end of progressbar.
     */
    void setCursorAtEnd() const;

    /**
     * set the minimum delay between to updates of the progress
     * bar display.
     * \param delay minimum refresh delay in second.
     * \see refresh_delay, setRefreshDelay(), update()
     */
    void setRefreshDelay(double delay);

    /**
     * Refresh the progress bar display.
     * \param force If true, doon't care about refresh_delay.
     * \see refresh_delay, setRefreshDelay()
     */
    void update(bool force = false) const;

    /**
     * Clear the progress bar from the display. This
     * doesn't reset either the timer, or the current
     * value!!!
     */
    void clear() const;

    /**
     * Change the cursor position in order to start a sub progress bar
     * (typically to start a sub task)
     */
    void StartSubProgressBar();

    /**
     * Change the cursor position in order to end a sub progress bar
     * (typically an ended sub task)
     */
    void EndSubProgressBar();

  };

}

#endif /*  __PROGRESSBAR_H */
// Local Variables:
// mode:c++
// End:
