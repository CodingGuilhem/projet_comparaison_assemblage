/******************************************************************************
*                                                                             *
* Copyright � 2007      -- Universit� de Antilles et de la Guyane             *
* Copyright � 2007-2008 -- Institut National de Recherche en Informatique et  *
*                          en Automatique                                     *
* Copyright � 2008-2023 -- LIRMM/CNRS/UM                                      *
*                          (Laboratoire d'Informatique, de Robotique et de    *
*                          Micro�lectronique de Montpellier /                 *
*                          Centre National de la Recherche Scientifique /     *
*                          Universit� de Montpellier)                         *
*                                                                             *
*  Auteurs/Authors: Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  Programmeurs/Programmers:                                                  *
*                   Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  -------------------------------------------------------------------------  *
*                                                                             *
* This File (which initially comes from StatiSTARS) is part of the C++        *
* ProgressBar library.                                                        *
*                                                                             *
* This library is free software; you can redistribute it and/or modify it     *
* under the terms of the GNU Library General Public License as published by   *
* the Free Software Foundation; either version 2 of the License, or (at your  *
* option) any later version.                                                  *
*                                                                             *
* This library is distributed in the hope that it will be useful, but WITHOUT *
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or       *
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public       *
* License for more details.                                                   *
*                                                                             *
* You should have received a copy of the GNU Library General Public License   *
* along with this library; if not, write:                                     *
*                                                                             *
*                    the Free Software Foundation, Inc.,                      *
*                    59 Temple Place - Suite 330,                             *
*                    Boston, MA  02111-1307, USA.                             *
*                                                                             *
******************************************************************************/
#include "progressBar.h"
#include <iomanip>

#define MAX_VAL 1000

using namespace DoccY;
using namespace std;

void testPB(ProgressBar &pb, double tps, bool fake = false) {

  pb.Reset();
  double ftps = tps / pb.GetMaxVal();
  if (fake) {
    tps = 5;
  }
  tps /= MAX_VAL;
  for(unsigned int i = 0; i < pb.GetMaxVal(); i++) {
    clock_t timer = clock();
    pb.Step();
    if (fake) {
      pb.AddTime(ftps);
    }
    while ((clock() - timer)/double(CLOCKS_PER_SEC) < tps);
  } /* Fin Pour */
  if (fake) {
    pb.Reset();
    pb.AddTime(ftps * pb.GetMaxVal());
    pb.SetVal(pb.GetMaxVal());
  }
  pb.update(true);
} /* Fin testPB */

int main(int argc, char** argv) {

  ProgressBar PB("ProgressBar Test Program", MAX_VAL, 80, cout, false);
  for (int i = 1; i <= 8; i++) {
    cout << setfill(' ') << setw(10) << i*10;
  }
  cout << endl;
  for (int i = 0; i < 8; i++) {
    cout << setfill('-') << setw(10) << "+";
  }
  cout << endl;

  float tps = 5;
  PB.setRefreshDelay(0.01);

  cout << "Test with percent and without time [default] (" << tps << "s):" << endl;
  testPB(PB, tps);
  cout << endl;

  cout << "Test with percent and time (" << tps << "s):" << endl;
  PB.ShowTime();
  testPB(PB, tps);
  cout << endl;

  cout << "Test without percent and with time (" << tps << "s):" << endl;
  PB.HidePercent();
  testPB(PB, tps);
  cout << endl;

  cout << "Test without percent and without time (" << tps << "s)" << endl;
  PB.HideTime();
  testPB(PB, tps);
  cout << endl;

  cout << "Test without percent and with time (2 min [displayed in 5s])" << endl;
  PB.ShowPercent();
  PB.ShowTime();
  testPB(PB, 120.0, true);
  cout << endl;

  cout << "Test without percent and with time (1h30 [displayed in 5s])" << endl;
  PB.setTitle("Changing title using setTitle method");
  testPB(PB, (1*60.0+30.0)*60.0, true);
  cout << endl;

  PB.setTitle("Look at the time unit behaviour!!!");
  cout << "Test without percent and with time (15h15 [displayed in 5s])" << endl;
  PB.setTitle("Please, look...");
  testPB(PB, (15*60.0+15.0)*60.0, true);
  cout << endl;

  cout << "Test without percent and with time (22d22 [displayed in 5s])" << endl;
  testPB(PB, (22.0*24.0+22.0)*3600.0, true);
  PB.setTitle("That's All, Folks!!!");
  PB.update(true);
  cout << endl;

  PB.setTitle("Main PB with subtasks");
  PB.ShowPercent();
  PB.ShowTime();
  cout << "Test with sub tasks (hiding subtasks 2 and 3 when done)" << endl;
  ProgressBar PB_1("Test progress bar subtask 1", MAX_VAL/3, 80, cout);
  ProgressBar PB_2("Test progress bar subtask 2", MAX_VAL/3, 80, cout);
  ProgressBar PB_3("Test progress bar subtask 3", MAX_VAL/3, 80, cout);
  PB.Reset();
  PB.update(true);
  PB.StartSubProgressBar();
  testPB(PB_1, tps);
  PB.SetVal(MAX_VAL/3, true);
  PB.EndSubProgressBar();

  PB.StartSubProgressBar();
  PB.StartSubProgressBar();
  testPB(PB_2, tps);
  PB.SetVal(2*MAX_VAL/3, true);
  PB.EndSubProgressBar();
  PB.EndSubProgressBar();

  PB.StartSubProgressBar();
  PB.StartSubProgressBar();
  testPB(PB_3, tps);
  PB_3.clear();
  PB.SetVal(MAX_VAL, true);
  PB.EndSubProgressBar();
  PB.EndSubProgressBar();
  cout << endl << endl << "That's All, Folks!!!" << endl;
  return 0;
}
